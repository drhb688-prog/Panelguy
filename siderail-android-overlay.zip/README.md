# SideRail Overlay — Cloud APK Build (No Android Studio Required)

This project was exported from SideRail with your current settings baked in:
- Size: 75dp x 400dp right-edge floating overlay
- Capacity: Unlimited scrollable apps
- Dark Mode: true
- Icon Theme: monochrome-ink
- Icon Shape: rounded
- Thumb Height: 73%
- Haptic Feedback: true

## Build Your Pixel APK in the Browser (2 Minutes)
1. Unzip this folder on your phone or computer.
2. Create a new repository on https://github.com (free account).
3. Upload all files inside this folder — make sure the hidden `.github/workflows/build-apk.yml` file is included!
   - Tip: If your file manager hides folders starting with a dot, show hidden files first, or create `.github/workflows/build-apk.yml` directly in GitHub using **Add file -> Create new file**.
4. Open the **Actions** tab in your GitHub repository and wait ~2 minutes for **Build SideRail Android APK** to turn green.
5. Tap the completed run -> download **SideRail-Overlay-APK** -> unzip it and tap `app-debug.apk` on your Pixel 11 Pro to install!
6. Open **SideRail Overlay**, tap **Grant Overlay** (allow *Display over other apps*), pick your installed Pixel apps, and tap **Start SideRail**.
