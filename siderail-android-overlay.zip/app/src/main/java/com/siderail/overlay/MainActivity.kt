package com.siderail.overlay

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    data class InstalledApp(
        val packageName: String,
        val label: String,
        val icon: Drawable
    )

    private val allApps = mutableListOf<InstalledApp>()
    private val filteredApps = mutableListOf<InstalledApp>()
    private lateinit var appAdapter: CatalogAdapter
    private lateinit var overlayToggleBtn: Button
    private lateinit var permissionBtn: Button
    private lateinit var statusLine: TextView

    private val themes = listOf(
        "native-glass" to "Native Glass",
        "squircle-vivid" to "Vivid Tint",
        "monochrome-ink" to "Monochrome",
        "tinted-pastel" to "Tinted Pastel",
        "outline-wire" to "Outline Wire",
        "anodized-matte" to "Anodized Matte"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyNightMode()
        loadInstalledApps()
        seedInitialAppsIfNeeded()
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshStatusUi()
    }

    private fun applyNightMode() {
        val mode = if (WidgetPrefs.isDarkMode(this)) {
            AppCompatDelegate.MODE_NIGHT_YES
        } else {
            AppCompatDelegate.MODE_NIGHT_NO
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    private fun loadInstalledApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(intent, 0)
        val seen = HashSet<String>()
        allApps.clear()

        for (info in resolved) {
            val pkg = info.activityInfo.packageName
            if (pkg == packageName || !seen.add(pkg)) continue
            val label = info.loadLabel(pm).toString()
            val icon = info.loadIcon(pm)
            allApps.add(InstalledApp(pkg, label, icon))
        }
        allApps.sortBy { it.label.lowercase() }
        filteredApps.clear()
        filteredApps.addAll(allApps)
    }

    private fun seedInitialAppsIfNeeded() {
        if (WidgetPrefs.isInitialized(this)) return
        val matched = mutableListOf<String>()
        for (keyword in WidgetPrefs.STARTER_KEYWORDS) {
            val found = allApps.firstOrNull { app ->
                app.label.contains(keyword, ignoreCase = true) ||
                    app.packageName.contains(keyword, ignoreCase = true)
            }
            if (found != null && !matched.contains(found.packageName)) {
                matched.add(found.packageName)
            }
        }
        if (matched.isEmpty()) {
            matched.addAll(allApps.take(10).map { it.packageName })
        }
        WidgetPrefs.setPackages(this, matched)
        WidgetPrefs.markInitialized(this)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun notifyOverlayRefresh() {
        if (OverlayService.isRunning) {
            sendBroadcast(Intent(OverlayService.ACTION_REFRESH).setPackage(packageName))
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(16))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(
                dp(16) + bars.left,
                dp(16) + bars.top,
                dp(16) + bars.right,
                dp(16) + bars.bottom
            )
            insets
        }

        val title = TextView(this).apply {
            text = "SideRail Overlay"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "75dp x 400dp right-edge launcher · Unlimited apps"
            textSize = 13f
            alpha = 0.72f
        }
        root.addView(subtitle)

        statusLine = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(10), 0, dp(6))
        }
        root.addView(statusLine)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        }

        permissionBtn = Button(this).apply {
            text = "Grant Overlay Permission"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(6)
            }
            setOnClickListener {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }

        overlayToggleBtn = Button(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(6)
            }
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                    return@setOnClickListener
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    ActivityCompat.requestPermissions(
                        this@MainActivity,
                        arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                        101
                    )
                }
                if (OverlayService.isRunning) {
                    stopService(Intent(this@MainActivity, OverlayService::class.java))
                } else {
                    val svc = Intent(this@MainActivity, OverlayService::class.java)
                    ContextCompat.startForegroundService(this@MainActivity, svc)
                }
                overlayToggleBtn.postDelayed({ refreshStatusUi() }, 250)
            }
        }

        btnRow.addView(permissionBtn)
        btnRow.addView(overlayToggleBtn)
        root.addView(btnRow)

        // Controls: Dark Mode, Labels, Haptics
        val switchesRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }

        val darkSwitch = Switch(this).apply {
            text = "Dark "
            isChecked = WidgetPrefs.isDarkMode(this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnCheckedChangeListener { _, checked ->
                WidgetPrefs.setDarkMode(this@MainActivity, checked)
                notifyOverlayRefresh()
                applyNightMode()
            }
        }

        val labelSwitch = Switch(this).apply {
            text = "Labels "
            isChecked = WidgetPrefs.showMicroLabels(this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnCheckedChangeListener { _, checked ->
                WidgetPrefs.setShowMicroLabels(this@MainActivity, checked)
                notifyOverlayRefresh()
            }
        }

        val hapticSwitch = Switch(this).apply {
            text = "Haptic "
            isChecked = WidgetPrefs.isHapticEnabled(this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnCheckedChangeListener { _, checked ->
                WidgetPrefs.setHapticEnabled(this@MainActivity, checked)
                notifyOverlayRefresh()
            }
        }

        switchesRow.addView(darkSwitch)
        switchesRow.addView(labelSwitch)
        switchesRow.addView(hapticSwitch)
        root.addView(switchesRow)

        // Theme cycle button + vertical thumb slider
        val themeBtn = Button(this).apply {
            val current = WidgetPrefs.getThemeId(this@MainActivity)
            val label = themes.firstOrNull { it.first == current }?.second ?: "Native Glass"
            text = "Icon Theme: $label"
            setOnClickListener {
                val idx = themes.indexOfFirst { it.first == WidgetPrefs.getThemeId(this@MainActivity) }
                val next = themes[(idx + 1) % themes.size]
                WidgetPrefs.setThemeId(this@MainActivity, next.first)
                text = "Icon Theme: ${next.second}"
                notifyOverlayRefresh()
            }
        }
        root.addView(themeBtn)

        val heightLabel = TextView(this).apply {
            text = "Right-Edge Thumb Height: ${WidgetPrefs.getVerticalOffsetPct(this@MainActivity)}%"
            textSize = 12f
            setPadding(0, dp(8), 0, dp(2))
        }
        root.addView(heightLabel)

        val heightSeek = SeekBar(this).apply {
            max = 100
            progress = WidgetPrefs.getVerticalOffsetPct(this@MainActivity)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    heightLabel.text = "Right-Edge Thumb Height: $progress%"
                    if (fromUser) {
                        WidgetPrefs.setVerticalOffsetPct(this@MainActivity, progress)
                        notifyOverlayRefresh()
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(heightSeek)

        val searchInput = EditText(this).apply {
            hint = "Search installed Pixel apps..."
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8)
                bottomMargin = dp(6)
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val q = s?.toString()?.trim()?.lowercase() ?: ""
                    filteredApps.clear()
                    if (q.isEmpty()) {
                        filteredApps.addAll(allApps)
                    } else {
                        filteredApps.addAll(allApps.filter { it.label.lowercase().contains(q) })
                    }
                    appAdapter.notifyDataSetChanged()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        root.addView(searchInput)

        appAdapter = CatalogAdapter()
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = appAdapter
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        root.addView(rv)

        setContentView(root)
        refreshStatusUi()
    }

    private fun refreshStatusUi() {
        val canDraw = Settings.canDrawOverlays(this)
        val dockCount = WidgetPrefs.getPackages(this).size
        permissionBtn.isEnabled = !canDraw
        permissionBtn.text = if (canDraw) "Overlay Allowed" else "Grant Overlay"
        overlayToggleBtn.text = if (OverlayService.isRunning) "Stop SideRail" else "Start SideRail"
        statusLine.text = if (canDraw) {
            "Overlay permission ready · $dockCount apps in rail"
        } else {
            "Step 1: Tap 'Grant Overlay' and allow Display over other apps"
        }
    }

    inner class CatalogAdapter : RecyclerView.Adapter<CatalogAdapter.RowHolder>() {

        inner class RowHolder(
            val row: LinearLayout,
            val icon: ImageView,
            val name: TextView,
            val actionBtn: Button
        ) : RecyclerView.ViewHolder(row)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
            val row = LinearLayout(parent.context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(8), dp(4), dp(8))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val iv = ImageView(parent.context).apply {
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply {
                    marginEnd = dp(12)
                }
            }

            val tv = TextView(parent.context).apply {
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val btn = Button(parent.context)

            row.addView(iv)
            row.addView(tv)
            row.addView(btn)
            return RowHolder(row, iv, tv, btn)
        }

        override fun getItemCount(): Int = filteredApps.size

        override fun onBindViewHolder(holder: RowHolder, position: Int) {
            val item = filteredApps[position]
            val currentDock = WidgetPrefs.getPackages(this@MainActivity)
            val inDock = currentDock.contains(item.packageName)

            holder.icon.setImageDrawable(item.icon)
            holder.name.text = item.label
            holder.actionBtn.text = if (inDock) "Remove" else "Add"
            holder.actionBtn.setTextColor(
                if (inDock) Color.parseColor("#E11D48") else Color.parseColor("#2563EB")
            )

            holder.actionBtn.setOnClickListener {
                val updated = WidgetPrefs.getPackages(this@MainActivity)
                if (updated.contains(item.packageName)) {
                    updated.remove(item.packageName)
                } else {
                    updated.add(item.packageName)
                }
                WidgetPrefs.setPackages(this@MainActivity, updated)
                val adapterPos = holder.bindingAdapterPosition
                if (adapterPos != RecyclerView.NO_POSITION) {
                    notifyItemChanged(adapterPos)
                }
                refreshStatusUi()
                notifyOverlayRefresh()
            }
        }
    }
}
