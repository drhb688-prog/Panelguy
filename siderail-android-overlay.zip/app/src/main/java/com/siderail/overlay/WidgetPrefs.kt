package com.siderail.overlay

import android.content.Context
import android.content.SharedPreferences

object WidgetPrefs {
    private const val PREFS_NAME = "siderail_overlay_prefs"
    private const val KEY_INITIALIZED = "initialized"
    private const val KEY_PACKAGES = "dock_packages"
    private const val KEY_DARK_MODE = "dark_mode"
    private const val KEY_THEME_ID = "theme_id"
    private const val KEY_ICON_SHAPE = "icon_shape"
    private const val KEY_ACCENT_HEX = "accent_hex"
    private const val KEY_VERTICAL_PCT = "vertical_offset_pct"
    private const val KEY_GLASS_BLUR = "glass_blur"
    private const val KEY_SHOW_LABELS = "show_labels"
    private const val KEY_HAPTICS = "haptic_feedback"

    const val WIDGET_WIDTH_DP = 75
    const val WIDGET_HEIGHT_DP = 400

    val STARTER_KEYWORDS = listOf("messages", "mail", "browser", "transit", "files", "wallet", "weather", "calendar", "maps")

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isInitialized(context: Context): Boolean =
        prefs(context).getBoolean(KEY_INITIALIZED, false)

    fun markInitialized(context: Context) {
        prefs(context).edit().putBoolean(KEY_INITIALIZED, true).apply()
    }

    fun getPackages(context: Context): MutableList<String> {
        val raw = prefs(context).getString(KEY_PACKAGES, "") ?: ""
        if (raw.isBlank()) return mutableListOf()
        return raw.split("|").filter { it.isNotBlank() }.toMutableList()
    }

    fun setPackages(context: Context, packages: List<String>) {
        prefs(context).edit().putString(KEY_PACKAGES, packages.joinToString("|")).apply()
    }

    fun isDarkMode(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DARK_MODE, true)

    fun setDarkMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_DARK_MODE, enabled).apply()
    }

    fun getThemeId(context: Context): String =
        prefs(context).getString(KEY_THEME_ID, "monochrome-ink") ?: "monochrome-ink"

    fun setThemeId(context: Context, themeId: String) {
        prefs(context).edit().putString(KEY_THEME_ID, themeId).apply()
    }

    fun getIconShape(context: Context): String =
        prefs(context).getString(KEY_ICON_SHAPE, "rounded") ?: "rounded"

    fun setIconShape(context: Context, shape: String) {
        prefs(context).edit().putString(KEY_ICON_SHAPE, shape).apply()
    }

    fun getAccentHex(context: Context): String =
        prefs(context).getString(KEY_ACCENT_HEX, "#059669") ?: "#059669"

    fun setAccentHex(context: Context, hex: String) {
        prefs(context).edit().putString(KEY_ACCENT_HEX, hex).apply()
    }

    fun getVerticalOffsetPct(context: Context): Int =
        prefs(context).getInt(KEY_VERTICAL_PCT, 73)

    fun setVerticalOffsetPct(context: Context, pct: Int) {
        prefs(context).edit().putInt(KEY_VERTICAL_PCT, pct.coerceIn(0, 100)).apply()
    }

    fun getGlassBlur(context: Context): String =
        prefs(context).getString(KEY_GLASS_BLUR, "frosted") ?: "frosted"

    fun setGlassBlur(context: Context, blur: String) {
        prefs(context).edit().putString(KEY_GLASS_BLUR, blur).apply()
    }

    fun showMicroLabels(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SHOW_LABELS, true)

    fun setShowMicroLabels(context: Context, show: Boolean) {
        prefs(context).edit().putBoolean(KEY_SHOW_LABELS, show).apply()
    }

    fun isHapticEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_HAPTICS, true)

    fun setHapticEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_HAPTICS, enabled).apply()
    }
}
