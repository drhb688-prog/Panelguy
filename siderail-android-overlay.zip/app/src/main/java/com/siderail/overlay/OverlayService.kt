package com.siderail.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Collections

class OverlayService : Service() {

    companion object {
        const val ACTION_REFRESH = "com.siderail.overlay.ACTION_REFRESH"
        const val ACTION_STOP = "com.siderail.overlay.ACTION_STOP"
        private const val CHANNEL_ID = "siderail_overlay_channel"
        private const val NOTIF_ID = 1042
        var isRunning: Boolean = false
            private set
    }

    data class DockApp(
        val packageName: String,
        val label: String,
        val icon: Drawable
    )

    private lateinit var windowManager: WindowManager
    private lateinit var layoutParams: WindowManager.LayoutParams
    private var rootView: View? = null
    private var railContainer: LinearLayout? = null
    private var collapsedTab: TextView? = null
    private var recyclerView: RecyclerView? = null
    private var clearAllBtn: TextView? = null
    private var editToggleBtn: TextView? = null
    private var countLabel: TextView? = null
    private var adapter: DockAdapter? = null

    private var isEditMode = false
    private var isCollapsed = false
    private val dockApps = mutableListOf<DockApp>()

    private val refreshReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_REFRESH) {
                reloadAndRender()
            } else if (intent?.action == ACTION_STOP) {
                stopSelf()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundNotification()

        val filter = IntentFilter().apply {
            addAction(ACTION_REFRESH)
            addAction(ACTION_STOP)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(refreshReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(refreshReceiver, filter)
        }

        buildOverlayWindow()
        reloadAndRender()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        reloadAndRender()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        try {
            unregisterReceiver(refreshReceiver)
        } catch (_: Exception) {
        }
        rootView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        rootView = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "SideRail Edge Overlay",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps the 75dp x 400dp right-edge launcher rail active"
        }
        manager.createNotificationChannel(channel)

        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SideRail Overlay Active")
            .setContentText("75x400 right-edge rail is running")
            .setSmallIcon(R.drawable.ic_siderail)
            .setContentIntent(openAppIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun screenHeightPx(): Int = resources.displayMetrics.heightPixels

    private fun computeYFromPct(pct: Int): Int {
        val widgetH = dp(WidgetPrefs.WIDGET_HEIGHT_DP)
        val topMargin = dp(40)
        val bottomMargin = dp(24)
        val travel = (screenHeightPx() - topMargin - bottomMargin - widgetH).coerceAtLeast(0)
        return topMargin + ((pct.coerceIn(0, 100) / 100f) * travel).toInt()
    }

    private fun buildOverlayWindow() {
        val widthPx = dp(WidgetPrefs.WIDGET_WIDTH_DP)
        val heightPx = dp(WidgetPrefs.WIDGET_HEIGHT_DP)

        layoutParams = WindowManager.LayoutParams(
            widthPx,
            heightPx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 0
            y = computeYFromPct(WidgetPrefs.getVerticalOffsetPct(this@OverlayService))
        }

        val container = FrameLayout(this)

        val rail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(widthPx, heightPx)
        }

        // Header row: Vertical drag grip + Edit toggle + Peek collapse
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(8), dp(6), dp(6))
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val dragGrip = TextView(this).apply {
            text = "::"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, dp(26), 1f)
            var startY = 0
            var startRawY = 0f
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startY = layoutParams.y
                        startRawY = event.rawY
                        haptic(longArrayOf(10))
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val widgetH = dp(WidgetPrefs.WIDGET_HEIGHT_DP)
                        val minY = dp(40)
                        val maxY = (screenHeightPx() - dp(24) - widgetH).coerceAtLeast(minY)
                        val nextY = (startY + (event.rawY - startRawY).toInt()).coerceIn(minY, maxY)
                        layoutParams.y = nextY
                        rootView?.let { windowManager.updateViewLayout(it, layoutParams) }
                        val pct = if (maxY > minY) (((nextY - minY).toFloat() / (maxY - minY)) * 100).toInt() else 78
                        WidgetPrefs.setVerticalOffsetPct(this@OverlayService, pct)
                        true
                    }
                    else -> false
                }
            }
        }

        val editBtn = TextView(this).apply {
            text = "Edit"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, dp(24), 1.3f)
            setOnClickListener {
                isEditMode = !isEditMode
                haptic(longArrayOf(10))
                applyThemeStyling()
                adapter?.notifyDataSetChanged()
            }
        }
        editToggleBtn = editBtn

        val peekBtn = TextView(this).apply {
            text = ">"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(18), dp(24))
            setOnClickListener {
                toggleCollapse(true)
            }
        }

        topRow.addView(dragGrip)
        topRow.addView(editBtn)
        topRow.addView(peekBtn)
        header.addView(topRow)

        val clearBtn = TextView(this).apply {
            text = "Clear All"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(24)
            ).apply { topMargin = dp(4) }
            setOnClickListener {
                dockApps.clear()
                WidgetPrefs.setPackages(this@OverlayService, emptyList())
                haptic(longArrayOf(16, 18, 12))
                adapter?.notifyDataSetChanged()
                updateCountLabel()
            }
        }
        clearAllBtn = clearBtn
        header.addView(clearBtn)

        rail.addView(header)

        // Scrollable Unlimited App List
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@OverlayService)
            overScrollMode = View.OVER_SCROLL_ALWAYS
            clipToPadding = false
            setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        val dockAdapter = DockAdapter()
        rv.adapter = dockAdapter
        adapter = dockAdapter

        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN,
            0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                Collections.swap(dockApps, from, to)
                dockAdapter.notifyItemMoved(from, to)
                WidgetPrefs.setPackages(this@OverlayService, dockApps.map { it.packageName })
                haptic(longArrayOf(8))
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        touchHelper.attachToRecyclerView(rv)

        recyclerView = rv
        rail.addView(rv)

        val footerCount = TextView(this).apply {
            textSize = 10f
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(5), dp(4), dp(6))
        }
        countLabel = footerCount
        rail.addView(footerCount)

        // Collapsed slim edge tab
        val tab = TextView(this).apply {
            text = "<"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(dp(22), dp(72), Gravity.END or Gravity.CENTER_VERTICAL)
            setOnClickListener {
                toggleCollapse(false)
            }
        }
        collapsedTab = tab

        railContainer = rail
        container.addView(rail)
        container.addView(tab)

        rootView = container
        windowManager.addView(container, layoutParams)
    }

    private fun toggleCollapse(collapse: Boolean) {
        isCollapsed = collapse
        haptic(longArrayOf(10))
        if (collapse) {
            railContainer?.visibility = View.GONE
            collapsedTab?.visibility = View.VISIBLE
            layoutParams.width = dp(24)
            layoutParams.height = dp(76)
        } else {
            railContainer?.visibility = View.VISIBLE
            collapsedTab?.visibility = View.GONE
            layoutParams.width = dp(WidgetPrefs.WIDGET_WIDTH_DP)
            layoutParams.height = dp(WidgetPrefs.WIDGET_HEIGHT_DP)
        }
        rootView?.let { windowManager.updateViewLayout(it, layoutParams) }
    }

    private fun reloadAndRender() {
        val pm = packageManager
        val saved = WidgetPrefs.getPackages(this)
        dockApps.clear()

        for (pkg in saved) {
            try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                val label = pm.getApplicationLabel(appInfo).toString()
                val icon = pm.getApplicationIcon(appInfo)
                dockApps.add(DockApp(pkg, label, icon))
            } catch (_: PackageManager.NameNotFoundException) {
            }
        }

        if (!isCollapsed) {
            layoutParams.y = computeYFromPct(WidgetPrefs.getVerticalOffsetPct(this))
            rootView?.let {
                try {
                    windowManager.updateViewLayout(it, layoutParams)
                } catch (_: Exception) {
                }
            }
        }

        applyThemeStyling()
        adapter?.notifyDataSetChanged()
        updateCountLabel()
    }

    private fun applyThemeStyling() {
        val dark = WidgetPrefs.isDarkMode(this)
        val blur = WidgetPrefs.getGlassBlur(this)
        val accentColor = try {
            Color.parseColor(WidgetPrefs.getAccentHex(this))
        } catch (_: Exception) {
            Color.parseColor("#2563EB")
        }

        val alpha = when (blur) {
            "solid" -> 244
            "subtle" -> 165
            else -> 214
        }

        val baseColor = if (dark) {
            Color.argb(alpha, 24, 24, 27)
        } else {
            Color.argb(alpha, 255, 255, 255)
        }
        val strokeColor = if (dark) Color.argb(60, 255, 255, 255) else Color.argb(36, 0, 0, 0)

        val r = dp(24).toFloat()
        val bg = GradientDrawable().apply {
            setColor(baseColor)
            setStroke(dp(1), strokeColor)
            cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        }
        railContainer?.background = bg

        val tabBg = GradientDrawable().apply {
            setColor(baseColor)
            setStroke(dp(1), accentColor)
            val tr = dp(12).toFloat()
            cornerRadii = floatArrayOf(tr, tr, 0f, 0f, 0f, 0f, tr, tr)
        }
        collapsedTab?.background = tabBg
        collapsedTab?.setTextColor(if (dark) Color.WHITE else Color.BLACK)

        editToggleBtn?.let { btn ->
            if (isEditMode) {
                btn.background = GradientDrawable().apply {
                    setColor(accentColor)
                    cornerRadius = dp(6).toFloat()
                }
                btn.setTextColor(Color.WHITE)
            } else {
                btn.background = null
                btn.setTextColor(if (dark) Color.LTGRAY else Color.DKGRAY)
            }
        }

        clearAllBtn?.visibility = if (isEditMode) View.VISIBLE else View.GONE
        clearAllBtn?.let { btn ->
            btn.background = GradientDrawable().apply {
                setColor(Color.argb(32, 225, 29, 72))
                cornerRadius = dp(6).toFloat()
            }
            btn.setTextColor(if (dark) Color.parseColor("#FB7185") else Color.parseColor("#E11D48"))
        }

        // Update header text colors
        val header = railContainer?.getChildAt(0) as? LinearLayout
        val topRow = header?.getChildAt(0) as? LinearLayout
        val textColor = if (dark) Color.parseColor("#E4E4E7") else Color.parseColor("#334155")
        (topRow?.getChildAt(0) as? TextView)?.setTextColor(textColor)
        (topRow?.getChildAt(2) as? TextView)?.setTextColor(textColor)
        countLabel?.setTextColor(if (dark) Color.parseColor("#A1A1AA") else Color.parseColor("#64748B"))
    }

    private fun updateCountLabel() {
        val count = dockApps.size
        countLabel?.text = if (count == 1) "1 app" else "$count apps"
    }

    private fun haptic(pattern: LongArray) {
        if (!WidgetPrefs.isHapticEnabled(this)) return
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as? Vibrator
        }
        vibrator?.let {
            if (pattern.size == 1) {
                it.vibrate(VibrationEffect.createOneShot(pattern[0], VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                it.vibrate(VibrationEffect.createWaveform(pattern, -1))
            }
        }
    }

    inner class DockAdapter : RecyclerView.Adapter<DockAdapter.Holder>() {

        inner class Holder(
            val wrapper: FrameLayout,
            val iconHolder: FrameLayout,
            val iconView: ImageView,
            val labelView: TextView,
            val removeBtn: TextView
        ) : RecyclerView.ViewHolder(wrapper)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val wrapper = FrameLayout(parent.context).apply {
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(6)
                }
            }

            val column = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(2), dp(3), dp(2), dp(3))
            }

            val iconBox = FrameLayout(parent.context).apply {
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
            }

            val iv = ImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = FrameLayout.LayoutParams(
                    dp(32),
                    dp(32),
                    Gravity.CENTER
                )
            }
            iconBox.addView(iv)

            val tv = TextView(parent.context).apply {
                textSize = 9.5f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(2) }
            }

            column.addView(iconBox)
            column.addView(tv)
            wrapper.addView(column)

            val remove = TextView(parent.context).apply {
                text = "×"
                textSize = 11f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                layoutParams = FrameLayout.LayoutParams(
                    dp(18),
                    dp(18),
                    Gravity.TOP or Gravity.END
                )
            }
            wrapper.addView(remove)

            return Holder(wrapper, iconBox, iv, tv, remove)
        }

        override fun getItemCount(): Int = dockApps.size

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = dockApps[position]
            val dark = WidgetPrefs.isDarkMode(this@OverlayService)
            val themeId = WidgetPrefs.getThemeId(this@OverlayService)
            val shape = WidgetPrefs.getIconShape(this@OverlayService)
            val showLabels = WidgetPrefs.showMicroLabels(this@OverlayService)
            val accentColor = try {
                Color.parseColor(WidgetPrefs.getAccentHex(this@OverlayService))
            } catch (_: Exception) {
                Color.parseColor("#2563EB")
            }

            val radiusPx = when (shape) {
                "circle" -> dp(22).toFloat()
                "rounded" -> dp(10).toFloat()
                else -> dp(15).toFloat()
            }

            val boxBg = GradientDrawable().apply {
                cornerRadius = radiusPx
                when (themeId) {
                    "monochrome-ink" -> setColor(if (dark) Color.parseColor("#F4F4F5") else Color.parseColor("#18181B"))
                    "outline-wire" -> {
                        setColor(if (dark) Color.argb(140, 12, 12, 14) else Color.argb(180, 255, 255, 255))
                        setStroke(dp(1), accentColor)
                    }
                    "anodized-matte" -> {
                        setColor(if (dark) Color.parseColor("#27272A") else Color.parseColor("#E2E8F0"))
                        setStroke(dp(1), Color.argb(40, 120, 120, 130))
                    }
                    "tinted-pastel" -> setColor(if (dark) Color.argb(65, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)) else Color.argb(38, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)))
                    "squircle-vivid" -> setColor(accentColor)
                    else -> setColor(if (dark) Color.argb(38, 255, 255, 255) else Color.argb(210, 255, 255, 255))
                }
            }
            holder.iconHolder.background = boxBg

            holder.iconView.setImageDrawable(item.icon)
            if (themeId == "monochrome-ink") {
                val cm = ColorMatrix().apply { setSaturation(0f) }
                holder.iconView.colorFilter = ColorMatrixColorFilter(cm)
            } else {
                holder.iconView.clearColorFilter()
            }

            holder.labelView.visibility = if (showLabels) View.VISIBLE else View.GONE
            holder.labelView.text = item.label
            holder.labelView.setTextColor(if (dark) Color.parseColor("#E4E4E7") else Color.parseColor("#1E293B"))

            holder.removeBtn.visibility = if (isEditMode) View.VISIBLE else View.GONE
            holder.removeBtn.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E11D48"))
            }

            holder.removeBtn.setOnClickListener {
                val idx = holder.bindingAdapterPosition
                if (idx != RecyclerView.NO_POSITION && idx < dockApps.size) {
                    dockApps.removeAt(idx)
                    WidgetPrefs.setPackages(this@OverlayService, dockApps.map { it.packageName })
                    haptic(longArrayOf(16, 18, 12))
                    notifyItemRemoved(idx)
                    updateCountLabel()
                }
            }

            holder.wrapper.setOnClickListener {
                if (isEditMode) return@setOnClickListener
                val launch = packageManager.getLaunchIntentForPackage(item.packageName)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    haptic(longArrayOf(14, 24, 18))
                    startActivity(launch)
                }
            }
        }
    }
}
